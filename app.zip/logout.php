<?php
// header('HTTP/1.1 401 Unauthorized');
// exit;

file_put_contents(__DIR__.'/logout.txt', json_encode($_GET));

